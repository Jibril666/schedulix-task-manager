# 📅 Schedulix — AI Task Manager MVP
**Kelompok 17 | KEB 1231 Technopreneurship for AI | IPB University**
> Jibril Alhafidz · Rachel Rehoboth L · Ramadhan Tri A

---

## 📁 Struktur Project

```
schedulix/
├── frontend/
│   └── index.html          ← Buka langsung di browser
├── backend/
│   ├── app.py              ← Flask API server
│   └── requirements.txt    ← Dependency Python
└── README.md
```

---

## 🚀 Cara Menjalankan

### Step 1 — Jalankan Backend

```bash
# Masuk ke folder backend
cd schedulix/backend

# (Opsional tapi disarankan) Buat virtual environment
python -m venv venv

# Aktifkan venv
source venv/bin/activate        # Mac / Linux
venv\Scripts\activate           # Windows

# Install dependency
pip install -r requirements.txt

# Jalankan server
python app.py
```

✅ Backend berjalan di → **http://localhost:5000**

---

### Step 2 — Buka Frontend

Cukup buka file `frontend/index.html` di browser:

```bash
# Mac
open frontend/index.html

# Windows
start frontend/index.html

# Atau drag & drop file ke Chrome/Firefox
```

✅ Tidak perlu web server tambahan.

---

## 🗄️ Setup Database MongoDB (Opsional)

Tanpa MongoDB, backend otomatis pakai **in-memory storage**
(data hilang saat server restart).

### Opsi A — MongoDB Lokal
1. Download: https://www.mongodb.com/try/download/community
2. Jalankan: `mongod`
3. URI sudah diset ke `mongodb://localhost:27017/` secara default ✅

### Opsi B — MongoDB Atlas (Cloud, Gratis)
1. Daftar di https://www.mongodb.com/atlas
2. Buat cluster gratis
3. Set environment variable sebelum menjalankan `app.py`:
   ```bash
   # Mac / Linux
   export MONGO_URI="mongodb+srv://user:pass@cluster.mongodb.net/"

   # Windows
   set MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/
   ```

---

## 🔌 API Endpoints

| Method   | Endpoint           | Deskripsi            |
|----------|--------------------|----------------------|
| `GET`    | `/tasks`           | Ambil semua task     |
| `POST`   | `/tasks`           | Tambah task baru     |
| `PATCH`  | `/tasks/<id>`      | Update status task   |
| `DELETE` | `/tasks/<id>`      | Hapus task           |

### Contoh POST /tasks
```json
{
  "name": "Laporan Praktikum",
  "deadline": "2026-04-29",
  "priority": "high"
}
```

---

## 🛠️ Teknologi

| Layer     | Teknologi                        |
|-----------|----------------------------------|
| Frontend  | HTML · CSS · JavaScript (Vanilla)|
| Backend   | Python 3.x · Flask · Flask-CORS  |
| Database  | MongoDB (+ in-memory fallback)   |
| Font      | Caveat · Indie Flower · Patrick Hand |

---

## ✨ Fitur

- ✏️ Tambah task dengan nama, deadline, dan prioritas
- 🎨 Sticky note berwarna otomatis (merah = urgent, kuning = medium, hijau = santai)
- ✅ Tandai task selesai / batalkan
- 🗑️ Hapus task
- ⚠️ Deteksi otomatis task yang overdue
- 📴 Mode offline otomatis kalau backend belum jalan

---

## 👥 Tim Pengembang

| Nama                | Peran                        |
|---------------------|------------------------------|
| Jibril Alhafidz     | Frontend + AI Engineer       |
| Rachel Rehoboth L   | Backend + API                |
| Ramadhan Tri A      | Database + Testing           |
